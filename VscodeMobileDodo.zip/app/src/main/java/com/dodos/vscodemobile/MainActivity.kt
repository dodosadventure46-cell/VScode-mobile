package com.dodos.vscodemobile

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import com.dodos.vscodemobile.ai.AiProposedFileChange
import com.dodos.vscodemobile.ai.AiProvider
import com.dodos.vscodemobile.ai.AiUndoSnapshot
import com.dodos.vscodemobile.ai.UniversalAiAgent
import com.dodos.vscodemobile.engine.*
import com.dodos.vscodemobile.service.SessionGuardianService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

val ObsidianBg = Color(0xFF090B0E)
val GunmetalPanel = Color(0xFF11161F)
val SlateSurface = Color(0xFF161E2B)
val HudBorder = Color(0xFF223044)
val TitaniumCyan = Color(0xFF00E5FF)
val IndustrialAmber = Color(0xFFFF9E00)
val SignalEmerald = Color(0xFF00E676)
val MechaCrimson = Color(0xFFFF2A54)
val TextPrimary = Color(0xFFE2E8F0)
val TextMuted = Color(0xFF64748B)

enum class SidebarTab(val label: String) {
    EXPLORER("EXPLORER"),
    SEARCH("SEARCH"),
    GIT("GIT REPO"),
    PLUGINS("PLUGINS"),
    AI_AGENT("AI AGENT"),
    SFTP("SFTP SYNC"),
    SETTINGS("ENGINE & CFG")
}

class MainActivity : ComponentActivity() {

    private lateinit var engineManager: HybridEngineManager
    private lateinit var aiAgent: UniversalAiAgent
    private var webViewRef: WebView? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private var currentActiveFilePath: String = ""
    private var currentOpenFiles: MutableList<String> = mutableListOf()
    private var currentFontSizePx: Int = 14
    private var currentCursorLine: Int = 1
    private var currentCursorCol: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engineManager = HybridEngineManager(this)
        aiAgent = UniversalAiAgent(this)

        SessionGuardianService.onSaveSessionCallback = {
            saveCurrentSessionSnapshot()
        }
        SessionGuardianService.onForceFinishActivityCallback = {
            runOnUiThread {
                finishAndRemoveTask()
            }
        }

        startGuardianService(SessionGuardianService.ACTION_START_GUARD)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = TitaniumCyan,
                    secondary = IndustrialAmber,
                    background = ObsidianBg,
                    surface = GunmetalPanel,
                    onPrimary = Color.Black,
                    onBackground = TextPrimary,
                    onSurface = TextPrimary
                )
            ) {
                VscodeMobileDodoScreen()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        startGuardianService(SessionGuardianService.ACTION_APP_FOREGROUNDED)
    }

    override fun onStop() {
        super.onStop()
        saveCurrentSessionSnapshot()
        startGuardianService(SessionGuardianService.ACTION_APP_BACKGROUNDED)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        super.onDestroy()
    }

    private fun startGuardianService(action: String) {
        try {
            val intent = Intent(this, SessionGuardianService::class.java).apply {
                this.action = action
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && action == SessionGuardianService.ACTION_START_GUARD) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        } catch (_: Exception) {}
    }

    private fun saveCurrentSessionSnapshot() {
        try {
            engineManager.saveLastSessionState(
                SavedSessionState(
                    engineMode = engineManager.currentMode,
                    activeWorkspacePath = engineManager.getActiveWorkspaceRoot(),
                    openFiles = currentOpenFiles.toList(),
                    activeFilePath = currentActiveFilePath,
                    cursorLine = currentCursorLine,
                    cursorColumn = currentCursorCol,
                    fontSizePx = currentFontSizePx,
                    timestamp = System.currentTimeMillis()
                )
            )
        } catch (_: Exception) {}
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Composable
    fun VscodeMobileDodoScreen() {
        val context = LocalContext.current
        val scope = rememberCoroutineScope()

        val restoredSession = remember { engineManager.loadLastSessionState() }

        var engineMode by remember { mutableStateOf(engineManager.currentMode) }
        var sshConnected by remember { mutableStateOf(engineManager.isSshConnected()) }
        var statusBanner by remember { mutableStateOf("SYSTEM READY • HYBRID VSCODE ENGINE") }

        var isSidebarVisible by remember { mutableStateOf(true) }
        var activeSidebarTab by remember { mutableStateOf(SidebarTab.EXPLORER) }
        var isTerminalVisible by remember { mutableStateOf(false) }
        var isLivePreviewVisible by remember { mutableStateOf(false) }

        var currentDirectory by remember { mutableStateOf(engineManager.getActiveWorkspaceRoot()) }
        var fileNodes by remember { mutableStateOf<List<FileNode>>(emptyList()) }
        var openTabs by remember { mutableStateOf<List<String>>(restoredSession?.openFiles ?: emptyList()) }
        var activeFilePath by remember { mutableStateOf(restoredSession?.activeFilePath ?: "") }
        var activeFileContent by remember { mutableStateOf("") }
        var editorFontSize by remember { mutableIntStateOf(restoredSession?.fontSizePx ?: 14) }

        var terminalOutput by remember {
            mutableStateOf("[HUD_TERM] VscodeMobileDodo Smart Terminal siap.\nKetuk tombol Quick Action di atas atau ketik perintah di bawah.\n")
        }
        var terminalInput by remember { mutableStateOf("") }
        var isRunningCommand by remember { mutableStateOf(false) }

        var aiPromptInput by remember { mutableStateOf("") }
        var aiLoading by remember { mutableStateOf(false) }
        var aiLastExplanation by remember {
            mutableStateOf("Hai! Aku AI Code Agent VscodeMobileDodo. Kamu bisa tanya \"AI, file ku sudah cukup bagus belum?\", \"AI, buatkan aku...\", atau klik tombol mikrofon untuk bicara langsung.")
        }
        var aiProposedChanges by remember { mutableStateOf<List<AiProposedFileChange>>(emptyList()) }
        var aiUndoCount by remember { mutableIntStateOf(aiAgent.getUndoCount()) }
        var isListeningVoice by remember { mutableStateOf(false) }

        var lastUserTouchMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
        var batteryPercent by remember { mutableIntStateOf(100) }
        var batteryTempC by remember { mutableFloatStateOf(32.0f) }
        var isPowerSaveIdle by remember { mutableStateOf(false) }

        var extSearchQuery by remember { mutableStateOf("theme") }
        var marketplaceExtensions by remember { mutableStateOf<List<VsCodeExtensionItem>>(emptyList()) }
        var installedExtensions by remember { mutableStateOf(engineManager.getInstalledExtensions()) }
        var extLoading by remember { mutableStateOf(false) }

        val selectedSftpPaths = remember { mutableStateListOf<String>() }

        LaunchedEffect(activeFilePath, openTabs, editorFontSize) {
            currentActiveFilePath = activeFilePath
            currentOpenFiles = openTabs.toMutableList()
            currentFontSizePx = editorFontSize
        }

        fun refreshFileExplorer(targetDir: String = currentDirectory) {
            scope.launch {
                val res = engineManager.listFiles(targetDir)
                if (res.isSuccess) {
                    fileNodes = res.getOrDefault(emptyList())
                    currentDirectory = targetDir
                } else {
                    statusBanner = "WARN: ${res.exceptionOrNull()?.message ?: "Gagal memuat direktori"}"
                }
            }
        }

        fun openFileInEditor(path: String) {
            scope.launch {
                val res = engineManager.readFileContent(path)
                if (res.isSuccess) {
                    val content = res.getOrDefault("")
                    activeFilePath = path
                    activeFileContent = content
                    if (!openTabs.contains(path)) {
                        openTabs = openTabs + path
                    }
                    val escapedPath = org.json.JSONObject.quote(path)
                    val escapedContent = org.json.JSONObject.quote(content)
                    webViewRef?.evaluateJavascript("window.loadFileIntoWorkbench($escapedPath, $escapedContent);", null)
                    statusBanner = "OPENED // ${File(path).name}"
                } else {
                    statusBanner = "ERR // ${res.exceptionOrNull()?.message}"
                }
            }
        }

        LaunchedEffect(Unit) {
            val defaultWelcome = File(engineManager.localRootDir, "main.js").absolutePath
            if (engineManager.currentMode == EngineMode.SSH_REMOTE && engineManager.hasSavedSshCredentials()) {
                statusBanner = "AUTO-LOGIN SSH // Menghubungkan ke server tersimpan..."
                val conn = engineManager.connectSsh()
                if (conn.isSuccess) {
                    sshConnected = true
                    engineMode = EngineMode.SSH_REMOTE
                    currentDirectory = engineManager.getActiveWorkspaceRoot()
                    statusBanner = "SSH ONLINE // ${conn.getOrNull()}"
                } else {
                    sshConnected = false
                    engineManager.setEngineMode(EngineMode.LOCAL)
                    engineMode = EngineMode.LOCAL
                    currentDirectory = engineManager.localRootDir.absolutePath
                    statusBanner = "SSH OFFLINE (Sinyal belum tersedia) • Beralih ke Mode Lokal"
                }
            }
            refreshFileExplorer(currentDirectory)
            val initialFile = if (activeFilePath.isNotBlank()) activeFilePath else defaultWelcome
            openFileInEditor(initialFile)
        }

        LaunchedEffect(Unit) {
            while (true) {
                val bmIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                if (bmIntent != null) {
                    val level = bmIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, 100)
                    val scale = bmIntent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                    batteryPercent = (level * 100) / scale
                    val tempTenths = bmIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 320)
                    batteryTempC = tempTenths / 10.0f
                }
                val idleMs = System.currentTimeMillis() - lastUserTouchMs
                isPowerSaveIdle = (idleMs > 15_000L) || (batteryPercent <= 20) || (batteryTempC >= 41.0f)
                delay(if (isPowerSaveIdle) 6_000L else 2_500L)
            }
        }

        val exportFolderLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.OpenDocumentTree()
        ) { treeUri: Uri? ->
            if (treeUri != null) {
                scope.launch {
                    try {
                        val pickedDir = DocumentFile.fromTreeUri(context, treeUri)
                        if (pickedDir != null) {
                            val activeName = File(activeFilePath.ifBlank { "main.js" }).name
                            val existingDoc = pickedDir.findFile(activeName)
                            val targetDoc = existingDoc ?: pickedDir.createFile("text/plain", activeName)
                            if (targetDoc != null) {
                                context.contentResolver.openOutputStream(targetDoc.uri)?.use { os ->
                                    os.write(activeFileContent.toByteArray(Charsets.UTF_8))
                                }
                            }
                            val zipName = "VscodeMobileDodo_Workspace_${System.currentTimeMillis() / 1000}.zip"
                            val zipDoc = pickedDir.createFile("application/zip", zipName)
                            if (zipDoc != null) {
                                val zipBytes = engineManager.exportWorkspaceToZipBytes()
                                context.contentResolver.openOutputStream(zipDoc.uri)?.use { os ->
                                    os.write(zipBytes)
                                }
                            }
                            statusBanner = "EXPORT SUKSES // File & ZIP disimpan ke folder pilihanmu!"
                            Toast.makeText(context, "Berhasil diekspor ke folder pilihan!", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        statusBanner = "EXPORT ERR // ${e.message}"
                    }
                }
            }
        }

        val importFileLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri: Uri? ->
            if (uri != null) {
                scope.launch {
                    try {
                        val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
                        if (text.trim().startsWith("{") && text.contains("VscodeMobileDodo")) {
                            val res = engineManager.importFullConfigurationJson(text)
                            if (res.isSuccess) {
                                aiAgent.importAiPrefsFromJson(res.getOrDefault(org.json.JSONObject()))
                                installedExtensions = engineManager.getInstalledExtensions()
                                statusBanner = "RESTORE SUKSES // Semua pengaturan, SSH, AI Key & Plugin dipulihkan!"
                            }
                        } else {
                            val importedFile = File(engineManager.localRootDir, "imported_${System.currentTimeMillis() % 10000}.txt")
                            importedFile.writeText(text)
                            refreshFileExplorer()
                            openFileInEditor(importedFile.absolutePath)
                        }
                    } catch (e: Exception) {
                        statusBanner = "IMPORT ERR // ${e.message}"
                    }
                }
            }
        }

        val micPermissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) {
                startVoiceToAiRecognition(
                    onPartialOrFinal = { spoken -> aiPromptInput = spoken },
                    onStateChange = { listening -> isListeningVoice = listening }
                )
            } else {
                Toast.makeText(context, "Izin mikrofon diperlukan untuk fitur Voice-to-AI", Toast.LENGTH_SHORT).show()
            }
        }

        val hudAlpha by animateFloatAsState(
            targetValue = if (isPowerSaveIdle) 0.78f else 1.0f,
            animationSpec = tween(400),
            label = "hudPowerSaveAlpha"
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(ObsidianBg)
                .alpha(hudAlpha)
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            awaitPointerEvent()
                            lastUserTouchMs = System.currentTimeMillis()
                        }
                    }
                }
        ) {
            Surface(
                color = GunmetalPanel,
                border = BorderStroke(1.dp, HudBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { isSidebarVisible = !isSidebarVisible },
                            modifier = Modifier.size(30.dp)
                        ) {
                            Icon(
                                imageVector = if (isSidebarVisible) Icons.Default.MenuOpen else Icons.Default.Menu,
                                contentDescription = "Toggle Sidebar",
                                tint = TitaniumCyan
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "VSCODE//DODO",
                            color = TitaniumCyan,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = if (engineMode == EngineMode.SSH_REMOTE) Color(0xFF062E22) else Color(0xFF1A2436),
                            shape = CutCornerShape(4.dp),
                            border = BorderStroke(
                                1.dp,
                                if (engineMode == EngineMode.SSH_REMOTE) SignalEmerald else IndustrialAmber
                            ),
                            modifier = Modifier.clickable {
                                activeSidebarTab = SidebarTab.SETTINGS
                                isSidebarVisible = true
                            }
                        ) {
                            Text(
                                text = if (engineMode == EngineMode.SSH_REMOTE) {
                                    if (sshConnected) "SSH: ONLINE" else "SSH: SHIELD"
                                } else {
                                    "LOCAL ENGINE"
                                },
                                color = if (engineMode == EngineMode.SSH_REMOTE) SignalEmerald else IndustrialAmber,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val pendingShield = engineManager.getPendingRemoteDraftCount()
                        if (pendingShield > 0) {
                            Text(
                                text = "SHIELD:$pendingShield",
                                color = IndustrialAmber,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        }
                        Text(
                            text = "${batteryPercent}%•${batteryTempC.roundToInt()}°C" + if (isPowerSaveIdle) "[ECO]" else "",
                            color = if (isPowerSaveIdle) IndustrialAmber else TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                        IconButton(
                            onClick = { exportFolderLauncher.launch(null) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FolderShared,
                                contentDescription = "Pilih Folder Ekspor",
                                tint = IndustrialAmber,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = { isLivePreviewVisible = !isLivePreviewVisible },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Visibility,
                                contentDescription = "Live Preview",
                                tint = if (isLivePreviewVisible) SignalEmerald else TextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = { isTerminalVisible = !isTerminalVisible },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Terminal,
                                contentDescription = "Smart Terminal",
                                tint = if (isTerminalVisible) TitaniumCyan else TextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            if (openTabs.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0C1017))
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    openTabs.forEach { tabPath ->
                        val isSelected = tabPath == activeFilePath
                        Surface(
                            color = if (isSelected) SlateSurface else Color.Transparent,
                            shape = CutCornerShape(topStart = 5.dp, topEnd = 5.dp),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) TitaniumCyan else HudBorder
                            ),
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .clickable { openFileInEditor(tabPath) }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = File(tabPath).name,
                                    color = if (isSelected) TitaniumCyan else TextMuted,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "×",
                                    color = TextMuted,
                                    fontSize = 12.sp,
                                    modifier = Modifier.clickable {
                                        openTabs = openTabs - tabPath
                                        if (activeFilePath == tabPath && openTabs.isNotEmpty()) {
                                            openFileInEditor(openTabs.last())
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures { _, dragAmount ->
                            if (dragAmount > 38f && !isSidebarVisible) {
                                isSidebarVisible = true
                            } else if (dragAmount < -38f && isSidebarVisible) {
                                isSidebarVisible = false
                            }
                        }
                    }
            ) {
                Column(
                    modifier = Modifier
                        .width(42.dp)
                        .fillMaxHeight()
                        .background(GunmetalPanel)
                        .border(1.dp, HudBorder),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Top
                ) {
                    val navItems = listOf(
                        SidebarTab.EXPLORER to Icons.Default.Folder,
                        SidebarTab.SEARCH to Icons.Default.Search,
                        SidebarTab.GIT to Icons.Default.AccountTree,
                        SidebarTab.PLUGINS to Icons.Default.Extension,
                        SidebarTab.AI_AGENT to Icons.Default.AutoAwesome,
                        SidebarTab.SFTP to Icons.Default.SwapHoriz,
                        SidebarTab.SETTINGS to Icons.Default.Settings
                    )
                    navItems.forEach { (tab, icon) ->
                        val active = isSidebarVisible && activeSidebarTab == tab
                        IconButton(
                            onClick = {
                                if (activeSidebarTab == tab) {
                                    isSidebarVisible = !isSidebarVisible
                                } else {
                                    activeSidebarTab = tab
                                    isSidebarVisible = true
                                }
                            },
                            modifier = Modifier
                                .padding(vertical = 2.dp)
                                .size(36.dp)
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = tab.label,
                                tint = if (active) TitaniumCyan else TextMuted,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                AnimatedVisibility(visible = isSidebarVisible) {
                    Surface(
                        color = Color(0xFF0E131B),
                        border = BorderStroke(1.dp, HudBorder),
                        modifier = Modifier
                            .width(250.dp)
                            .fillMaxHeight()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "// ${activeSidebarTab.label}",
                                    color = IndustrialAmber,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "[HIDE]",
                                    color = TitaniumCyan,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    modifier = Modifier.clickable { isSidebarVisible = false }
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))

                            when (activeSidebarTab) {
                                SidebarTab.EXPLORER -> {
                                    var newItemName by remember { mutableStateOf("") }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = newItemName,
                                            onValueChange = { newItemName = it },
                                            placeholder = { Text("Nama file/folder...", fontSize = 10.sp) },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f),
                                            textStyle = LocalTextStyle.current.copy(
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        )
                                        SmallHudButton("+File") {
                                            if (newItemName.isNotBlank()) {
                                                scope.launch {
                                                    val res = engineManager.createNewFileOrFolder(currentDirectory, newItemName.trim(), false)
                                                    if (res.isSuccess) {
                                                        newItemName = ""
                                                        refreshFileExplorer()
                                                        res.getOrNull()?.let { openFileInEditor(it) }
                                                    }
                                                }
                                            }
                                        }
                                        SmallHudButton("+Dir") {
                                            if (newItemName.isNotBlank()) {
                                                scope.launch {
                                                    engineManager.createNewFileOrFolder(currentDirectory, newItemName.trim(), true)
                                                    newItemName = ""
                                                    refreshFileExplorer()
                                                }
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        SmallHudButton("↑ Induk") {
                                            val parent = File(currentDirectory).parent
                                            if (!parent.isNullOrBlank()) {
                                                refreshFileExplorer(parent)
                                            }
                                        }
                                        SmallHudButton("Refresh") { refreshFileExplorer() }
                                        SmallHudButton("Ekspor ke HP") { exportFolderLauncher.launch(null) }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = currentDirectory,
                                        color = TextMuted,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 9.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                                        items(fileNodes) { node ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        if (node.isDirectory) {
                                                            refreshFileExplorer(node.path)
                                                        } else {
                                                            openFileInEditor(node.path)
                                                        }
                                                    }
                                                    .padding(vertical = 5.dp, horizontal = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Icon(
                                                        imageVector = if (node.isDirectory) Icons.Default.Folder else Icons.Default.Description,
                                                        contentDescription = null,
                                                        tint = if (node.isDirectory) IndustrialAmber else TitaniumCyan,
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = node.name + if (node.hasOfflineDraft) " [SHIELD]" else "",
                                                        color = if (node.path == activeFilePath) TitaniumCyan else TextPrimary,
                                                        fontFamily = FontFamily.Monospace,
                                                        fontSize = 11.sp,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                                Text(
                                                    text = "✕",
                                                    color = MechaCrimson,
                                                    fontSize = 11.sp,
                                                    modifier = Modifier
                                                        .padding(start = 6.dp)
                                                        .clickable {
                                                            scope.launch {
                                                                engineManager.deleteFileOrFolder(node.path)
                                                                refreshFileExplorer()
                                                            }
                                                        }
                                                )
                                            }
                                        }
                                    }
                                }

                                SidebarTab.SEARCH -> {
                                    var searchKeyword by remember { mutableStateOf("") }
                                    var searchResults by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
                                    OutlinedTextField(
                                        value = searchKeyword,
                                        onValueChange = { searchKeyword = it },
                                        label = { Text("Cari di seluruh proyek...", fontSize = 10.sp) },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        SmallHudButton("Cari di Proyek") {
                                            scope.launch {
                                                val found = mutableListOf<Pair<String, String>>()
                                                for (node in fileNodes.filter { !it.isDirectory }) {
                                                    val txt = engineManager.readFileContent(node.path).getOrDefault("")
                                                    txt.lines().forEachIndexed { idx, line ->
                                                        if (line.contains(searchKeyword, ignoreCase = true)) {
                                                            found.add(node.path to "Baris ${idx + 1}: ${line.trim()}")
                                                        }
                                                    }
                                                }
                                                searchResults = found
                                            }
                                        }
                                        SmallHudButton("Find/Replace Editor") {
                                            webViewRef?.evaluateJavascript("window.toggleFindOverlay(true);", null)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                                        items(searchResults) { (path, snippet) ->
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable { openFileInEditor(path) }
                                                    .padding(vertical = 4.dp)
                                            ) {
                                                Text(File(path).name, color = TitaniumCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                                Text(snippet, color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
                                            }
                                        }
                                    }
                                }

                                SidebarTab.GIT -> {
                                    var commitMsg by remember { mutableStateOf("Update via VscodeMobileDodo") }
                                    var repoCloneUrl by remember { mutableStateOf("") }
                                    var gitLogOutput by remember { mutableStateOf("Klik tombol Git di bawah untuk mengontrol repositori langsung dari VS Code.") }

                                    OutlinedTextField(
                                        value = commitMsg,
                                        onValueChange = { commitMsg = it },
                                        label = { Text("Pesan Commit Git", fontSize = 10.sp) },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        SmallHudButton("Status") {
                                            scope.launch {
                                                gitLogOutput = engineManager.runTerminalCommand("git status")
                                            }
                                        }
                                        SmallHudButton("Commit All") {
                                            scope.launch {
                                                gitLogOutput = engineManager.runTerminalCommand("git add . && git commit -m \"$commitMsg\"")
                                            }
                                        }
                                        SmallHudButton("Push") {
                                            scope.launch {
                                                gitLogOutput = engineManager.runTerminalCommand("git push")
                                            }
                                        }
                                        SmallHudButton("Pull") {
                                            scope.launch {
                                                gitLogOutput = engineManager.runTerminalCommand("git pull")
                                                refreshFileExplorer()
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    OutlinedTextField(
                                        value = repoCloneUrl,
                                        onValueChange = { repoCloneUrl = it },
                                        label = { Text("URL Clone GitHub (https://...)", fontSize = 10.sp) },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    SmallHudButton("Git Clone Repo ke Workspace") {
                                        if (repoCloneUrl.isNotBlank()) {
                                            scope.launch {
                                                gitLogOutput = engineManager.runTerminalCommand("git clone $repoCloneUrl")
                                                refreshFileExplorer()
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = gitLogOutput,
                                        color = SignalEmerald,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(ObsidianBg)
                                            .padding(6.dp)
                                            .verticalScroll(rememberScrollState())
                                    )
                                }

                                SidebarTab.PLUGINS -> {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedTextField(
                                            value = extSearchQuery,
                                            onValueChange = { extSearchQuery = it },
                                            placeholder = { Text("Cari plugin OpenVSX...", fontSize = 10.sp) },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                        SmallHudButton(if (extLoading) "..." else "Cari") {
                                            scope.launch {
                                                extLoading = true
                                                val res = engineManager.searchOpenVsxExtensions(extSearchQuery)
                                                extLoading = false
                                                if (res.isSuccess) {
                                                    marketplaceExtensions = res.getOrDefault(emptyList())
                                                } else {
                                                    statusBanner = "OPENVSX ERR // ${res.exceptionOrNull()?.message}"
                                                }
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Terpasang: ${installedExtensions.size} Plugin Aktif",
                                        color = SignalEmerald,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                                        items(marketplaceExtensions.ifEmpty { installedExtensions }) { ext ->
                                            Surface(
                                                color = SlateSurface,
                                                shape = CutCornerShape(4.dp),
                                                border = BorderStroke(1.dp, HudBorder),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 3.dp)
                                            ) {
                                                Column(modifier = Modifier.padding(6.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = ext.name,
                                                            color = TitaniumCyan,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 11.sp,
                                                            maxLines = 1,
                                                            modifier = Modifier.weight(1f)
                                                        )
                                                        SmallHudButton(if (ext.isInstalled) "Installed" else "Install") {
                                                            scope.launch {
                                                                statusBanner = "Mengunduh plugin ${ext.name}..."
                                                                val r = engineManager.installExtensionFromOpenVsx(ext)
                                                                installedExtensions = engineManager.getInstalledExtensions()
                                                                statusBanner = r.getOrDefault("Gagal install plugin")
                                                            }
                                                        }
                                                    }
                                                    Text(
                                                        text = "${ext.publisher} • v${ext.version}",
                                                        color = IndustrialAmber,
                                                        fontSize = 9.sp,
                                                        fontFamily = FontFamily.Monospace
                                                    )
                                                    Text(
                                                        text = ext.description,
                                                        color = TextMuted,
                                                        fontSize = 10.sp,
                                                        maxLines = 2
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                SidebarTab.AI_AGENT -> {
                                    var selectedProvider by remember { mutableStateOf(aiAgent.getSelectedProvider()) }
                                    var apiKeyInput by remember { mutableStateOf(aiAgent.getApiKey(selectedProvider)) }
                                    var modelInput by remember { mutableStateOf(aiAgent.getSelectedModel(selectedProvider)) }
                                    var autoApply by remember { mutableStateOf(aiAgent.isAutoApplyEnabled()) }
                                    var showAiConfig by remember { mutableStateOf(apiKeyInput.isBlank()) }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        SmallHudButton(if (showAiConfig) "Tutup API Key" else "Atur Otak AI (${selectedProvider.name})") {
                                            showAiConfig = !showAiConfig
                                        }
                                        if (aiUndoCount > 0) {
                                            SmallHudButton("Undo AI ($aiUndoCount)") {
                                                val snap = aiAgent.popUndoSnapshot()
                                                if (snap != null) {
                                                    scope.launch {
                                                        for ((path, oldContent) in snap.previousFilesState) {
                                                            if (oldContent == null) {
                                                                engineManager.deleteFileOrFolder(path)
                                                            } else {
                                                                engineManager.writeFileContent(path, oldContent)
                                                                if (path == activeFilePath) {
                                                                    openFileInEditor(path)
                                                                }
                                                            }
                                                        }
                                                        aiUndoCount = aiAgent.getUndoCount()
                                                        refreshFileExplorer()
                                                        statusBanner = "UNDO AI // Perubahan dikembalikan ke versi sebelumnya!"
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    if (showAiConfig) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .horizontalScroll(rememberScrollState()),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            AiProvider.entries.forEach { prov ->
                                                SmallHudButton(
                                                    text = if (selectedProvider == prov) "[${prov.name}]" else prov.name
                                                ) {
                                                    selectedProvider = prov
                                                    aiAgent.setSelectedProvider(prov)
                                                    apiKeyInput = aiAgent.getApiKey(prov)
                                                    modelInput = aiAgent.getSelectedModel(prov)
                                                }
                                            }
                                        }
                                        OutlinedTextField(
                                            value = apiKeyInput,
                                            onValueChange = {
                                                apiKeyInput = it
                                                aiAgent.setApiKey(selectedProvider, it)
                                            },
                                            label = { Text("API Key ${selectedProvider.displayName} (Tersimpan Otomatis)", fontSize = 10.sp) },
                                            singleLine = true,
                                            visualTransformation = PasswordVisualTransformation(),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        OutlinedTextField(
                                            value = modelInput,
                                            onValueChange = {
                                                modelInput = it
                                                aiAgent.setSelectedModel(selectedProvider, it)
                                            },
                                            label = { Text("Nama Model (${selectedProvider.defaultModels.joinToString("/")})", fontSize = 9.sp) },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(
                                                checked = autoApply,
                                                onCheckedChange = {
                                                    autoApply = it
                                                    aiAgent.setAutoApplyEnabled(it)
                                                }
                                            )
                                            Text("Auto-Edit File Langsung (+Siapkan Tombol Undo)", fontSize = 10.sp, color = TextPrimary)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        SmallHudButton("Cek Kualitas File") {
                                            aiPromptInput = "AI, cek apakah file ku ini sudah cukup bagus belum? Tunjukkan jika ada bug dan perbaiki bila perlu."
                                        }
                                        SmallHudButton("Perbaiki Error Terminal") {
                                            aiPromptInput = "AI, analisis log error terminal terbaru dan langsung perbaiki file kode yang menyebabkannya."
                                        }
                                        SmallHudButton("Rapikan & Optimalkan") {
                                            aiPromptInput = "AI, rapikan struktur kode di file ini agar lebih bersih, cepat, dan bebas bug."
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = aiPromptInput,
                                            onValueChange = { aiPromptInput = it },
                                            placeholder = { Text("Perintahkan AI (misal: buatkan aku...)", fontSize = 10.sp) },
                                            maxLines = 3,
                                            modifier = Modifier.weight(1f)
                                        )
                                        IconButton(
                                            onClick = {
                                                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                                    startVoiceToAiRecognition(
                                                        onPartialOrFinal = { spoken -> aiPromptInput = spoken },
                                                        onStateChange = { listening -> isListeningVoice = listening }
                                                    )
                                                } else {
                                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                                }
                                            },
                                            modifier = Modifier
                                                .size(34.dp)
                                                .border(1.dp, if (isListeningVoice) MechaCrimson else IndustrialAmber, CutCornerShape(4.dp))
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Mic,
                                                contentDescription = "Perintah Suara AI",
                                                tint = if (isListeningVoice) MechaCrimson else IndustrialAmber,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Button(
                                        onClick = {
                                            if (aiPromptInput.isNotBlank() && !aiLoading) {
                                                scope.launch {
                                                    aiLoading = true
                                                    statusBanner = "AI AGENT // Menganalisis proyek & menyusun kode..."
                                                    val res = aiAgent.askAiCodeAgent(
                                                        userPrompt = aiPromptInput,
                                                        activeFilePath = activeFilePath,
                                                        activeFileContent = activeFileContent,
                                                        projectFileList = fileNodes.map { it.path },
                                                        recentTerminalLog = terminalOutput,
                                                        readExistingFileCallback = { p ->
                                                            engineManager.readFileContent(p).getOrNull()
                                                        }
                                                    )
                                                    aiLoading = false
                                                    if (res.isSuccess) {
                                                        val reply = res.getOrThrow()
                                                        aiLastExplanation = reply.explanationText
                                                        aiProposedChanges = reply.proposedChanges
                                                        if (autoApply && reply.proposedChanges.isNotEmpty()) {
                                                            val prevMap = mutableMapOf<String, String?>()
                                                            for (chg in reply.proposedChanges) {
                                                                val fullPath = resolveWorkspacePath(currentDirectory, chg.filePath)
                                                                prevMap[fullPath] = chg.previousContent
                                                                engineManager.writeFileContent(fullPath, chg.newContent)
                                                                if (fullPath == activeFilePath || reply.proposedChanges.size == 1) {
                                                                    openFileInEditor(fullPath)
                                                                }
                                                            }
                                                            aiAgent.pushUndoSnapshot(
                                                                AiUndoSnapshot(
                                                                    timestamp = System.currentTimeMillis(),
                                                                    summary = aiPromptInput.take(40),
                                                                    previousFilesState = prevMap
                                                                )
                                                            )
                                                            aiUndoCount = aiAgent.getUndoCount()
                                                            refreshFileExplorer()
                                                            statusBanner = "AI AUTO-EDIT // ${reply.proposedChanges.size} file diperbarui otomatis!"
                                                        } else {
                                                            statusBanner = "AI READY // Selesai menganalisis."
                                                        }
                                                    } else {
                                                        aiLastExplanation = "Error AI: ${res.exceptionOrNull()?.message}"
                                                        statusBanner = "AI ERR // Periksa API Key atau koneksi"
                                                    }
                                                }
                                            }
                                        },
                                        shape = CutCornerShape(5.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = if (aiLoading) "MEMPROSES OTAK AI..." else "KIRIM KE AI AGENT",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .verticalScroll(rememberScrollState())
                                    ) {
                                        Text(
                                            text = aiLastExplanation,
                                            color = TextPrimary,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.sp,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(ObsidianBg)
                                                .padding(6.dp)
                                        )
                                        aiProposedChanges.forEach { change ->
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Surface(
                                                color = SlateSurface,
                                                border = BorderStroke(1.dp, TitaniumCyan),
                                                shape = CutCornerShape(4.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(6.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "${change.action.uppercase()}: ${change.filePath}",
                                                            color = IndustrialAmber,
                                                            fontSize = 10.sp,
                                                            fontFamily = FontFamily.Monospace,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                        SmallHudButton("Terapkan") {
                                                            scope.launch {
                                                                val fullPath = resolveWorkspacePath(currentDirectory, change.filePath)
                                                                aiAgent.pushUndoSnapshot(
                                                                    AiUndoSnapshot(
                                                                        timestamp = System.currentTimeMillis(),
                                                                        summary = "Apply ${change.filePath}",
                                                                        previousFilesState = mapOf(fullPath to change.previousContent)
                                                                    )
                                                                )
                                                                aiUndoCount = aiAgent.getUndoCount()
                                                                engineManager.writeFileContent(fullPath, change.newContent)
                                                                refreshFileExplorer()
                                                                openFileInEditor(fullPath)
                                                            }
                                                        }
                                                    }
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = change.unifiedDiffPreview,
                                                        color = SignalEmerald,
                                                        fontFamily = FontFamily.Monospace,
                                                        fontSize = 9.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                SidebarTab.SFTP -> {
                                    Text(
                                        text = "Transfer Visual SFTP (Centang file untuk Unduh ke HP atau Unggah ke Server SSH):",
                                        color = TextMuted,
                                        fontSize = 10.sp
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        SmallHudButton("Unduh ke HP (${selectedSftpPaths.size})") {
                                            scope.launch {
                                                var ok = 0
                                                for (p in selectedSftpPaths) {
                                                    if (engineManager.downloadRemoteFileToLocal(p).isSuccess) ok++
                                                }
                                                statusBanner = "SFTP // $ok file berhasil diunduh ke Workspace Lokal HP!"
                                            }
                                        }
                                        SmallHudButton("Ekspor ke Folder HP") {
                                            exportFolderLauncher.launch(null)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                                        items(fileNodes.filter { !it.isDirectory }) { node ->
                                            val checked = selectedSftpPaths.contains(node.path)
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        if (checked) selectedSftpPaths.remove(node.path)
                                                        else selectedSftpPaths.add(node.path)
                                                    }
                                                    .padding(vertical = 3.dp)
                                            ) {
                                                Checkbox(
                                                    checked = checked,
                                                    onCheckedChange = {
                                                        if (it) selectedSftpPaths.add(node.path)
                                                        else selectedSftpPaths.remove(node.path)
                                                    }
                                                )
                                                Text(
                                                    text = "${node.name} (${node.sizeBytes / 1024} KB)",
                                                    color = TextPrimary,
                                                    fontSize = 10.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }
                                        }
                                    }
                                }

                                SidebarTab.SETTINGS -> {
                                    val savedCreds = remember { engineManager.loadSshCredentials() }
                                    var host by remember { mutableStateOf(savedCreds.host) }
                                    var port by remember { mutableStateOf(savedCreds.port.toString()) }
                                    var user by remember { mutableStateOf(savedCreds.username) }
                                    var pass by remember { mutableStateOf(savedCreds.password) }
                                    var remoteDir by remember { mutableStateOf(savedCreds.remoteWorkspace) }

                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .verticalScroll(rememberScrollState())
                                    ) {
                                        Text("PILIH MESIN INTI (HYBRID):", color = TitaniumCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            SmallHudButton(if (engineMode == EngineMode.LOCAL) "[MODE LOKAL AKTIF]" else "Gunakan Mode Lokal") {
                                                engineManager.setEngineMode(EngineMode.LOCAL)
                                                engineMode = EngineMode.LOCAL
                                                currentDirectory = engineManager.localRootDir.absolutePath
                                                refreshFileExplorer(currentDirectory)
                                                statusBanner = "ENGINE // Mode Lokal Aktif (Offline Ready)"
                                            }
                                            SmallHudButton(if (engineMode == EngineMode.SSH_REMOTE) "[MODE SSH AKTIF]" else "Gunakan Mode SSH") {
                                                scope.launch {
                                                    val creds = SshCredentials(
                                                        host = host,
                                                        port = port.toIntOrNull() ?: 22,
                                                        username = user,
                                                        password = pass,
                                                        remoteWorkspace = remoteDir
                                                    )
                                                    statusBanner = "SSH // Menyimpan & menghubungkan..."
                                                    val r = engineManager.connectSsh(creds)
                                                    if (r.isSuccess) {
                                                        sshConnected = true
                                                        engineMode = EngineMode.SSH_REMOTE
                                                        currentDirectory = creds.remoteWorkspace
                                                        refreshFileExplorer(currentDirectory)
                                                        statusBanner = "SSH TERHUBUNG (Tersimpan Permanen)"
                                                    } else {
                                                        statusBanner = "SSH GAGAL: ${r.exceptionOrNull()?.message}"
                                                    }
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text("KREDENSIAL SERVER SSH (SEKALI ISI, AUTO-LOGIN SELAMANYA):", color = IndustrialAmber, fontSize = 10.sp)
                                        OutlinedTextField(
                                            value = host,
                                            onValueChange = { host = it },
                                            label = { Text("IP / Host Server VPS", fontSize = 10.sp) },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            OutlinedTextField(
                                                value = user,
                                                onValueChange = { user = it },
                                                label = { Text("Username", fontSize = 10.sp) },
                                                singleLine = true,
                                                modifier = Modifier.weight(1f)
                                            )
                                            OutlinedTextField(
                                                value = port,
                                                onValueChange = { port = it },
                                                label = { Text("Port", fontSize = 10.sp) },
                                                singleLine = true,
                                                modifier = Modifier.width(70.dp)
                                            )
                                        }
                                        OutlinedTextField(
                                            value = pass,
                                            onValueChange = { pass = it },
                                            label = { Text("Password SSH (Terenkripsi)", fontSize = 10.sp) },
                                            singleLine = true,
                                            visualTransformation = PasswordVisualTransformation(),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        OutlinedTextField(
                                            value = remoteDir,
                                            onValueChange = { remoteDir = it },
                                            label = { Text("Folder Workspace di Server", fontSize = 10.sp) },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        SmallHudButton("Simpan Permanen & Sambungkan SSH") {
                                            scope.launch {
                                                val creds = SshCredentials(
                                                    host = host,
                                                    port = port.toIntOrNull() ?: 22,
                                                    username = user,
                                                    password = pass,
                                                    remoteWorkspace = remoteDir
                                                )
                                                val r = engineManager.connectSsh(creds)
                                                if (r.isSuccess) {
                                                    sshConnected = true
                                                    engineMode = EngineMode.SSH_REMOTE
                                                    currentDirectory = creds.remoteWorkspace
                                                    refreshFileExplorer(currentDirectory)
                                                    statusBanner = "SSH AUTO-LOGIN AKTIF // ${r.getOrNull()}"
                                                } else {
                                                    statusBanner = "SSH ERR // ${r.exceptionOrNull()?.message}"
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text("CADANGAN & PEMULIHAN (BACKUP PENGATURAN + PLUGIN + AI):", color = TitaniumCyan, fontSize = 10.sp)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            SmallHudButton("Backup ke File") {
                                                val json = engineManager.exportFullConfigurationJson(aiAgent.exportAiPrefsToJson())
                                                val backupFile = File(engineManager.localRootDir, "vscodedodo_backup.json")
                                                backupFile.writeText(json)
                                                refreshFileExplorer()
                                                statusBanner = "BACKUP // Tersimpan di vscodedodo_backup.json"
                                            }
                                            SmallHudButton("Impor Backup / File") {
                                                importFileLauncher.launch("*/*")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .pointerInput(Unit) {
                            detectTransformGestures { _, _, zoom, _ ->
                                if (zoom != 1f) {
                                    val newSize = (editorFontSize * zoom).roundToInt().coerceIn(10, 28)
                                    if (newSize != editorFontSize) {
                                        editorFontSize = newSize
                                        webViewRef?.evaluateJavascript("window.setEditorFontSize($newSize);", null)
                                    }
                                }
                            }
                        }
                ) {
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.allowFileAccess = true
                                webViewClient = WebViewClient()
                                webChromeClient = WebChromeClient()
                                addJavascriptInterface(
                                    object {
                                        @JavascriptInterface
                                        fun onContentModified(path: String, newContent: String) {
                                            activeFileContent = newContent
                                            engineManager.saveInstantDraftShield(
                                                path,
                                                newContent,
                                                isRemote = (engineManager.currentMode == EngineMode.SSH_REMOTE)
                                            )
                                        }

                                        @JavascriptInterface
                                        fun onCursorChanged(line: Int, col: Int) {
                                            currentCursorLine = line
                                            currentCursorCol = col
                                        }
                                    },
                                    "AndroidBridge"
                                )
                                loadUrl("file:///android_asset/vscode_workbench/index.html")
                                webViewRef = this
                            }
                        },
                        modifier = Modifier
                            .weight(if (isLivePreviewVisible) 0.55f else 1f)
                            .fillMaxWidth()
                    )

                    AnimatedVisibility(visible = isLivePreviewVisible) {
                        Surface(
                            color = ObsidianBg,
                            border = BorderStroke(1.dp, SignalEmerald),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                        ) {
                            Column(modifier = Modifier.fillMaxSize()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(GunmetalPanel)
                                        .padding(horizontal = 8.dp, vertical = 3.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("LIVE PREVIEW // ${File(activeFilePath).name}", color = SignalEmerald, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    Text("[TUTUP]", color = MechaCrimson, fontSize = 10.sp, modifier = Modifier.clickable { isLivePreviewVisible = false })
                                }
                                AndroidView(
                                    factory = { ctx -> WebView(ctx).apply { settings.javaScriptEnabled = true } },
                                    update = { wv ->
                                        wv.loadDataWithBaseURL(null, activeFileContent, "text/html", "UTF-8", null)
                                    },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }

            AnimatedVisibility(visible = isTerminalVisible) {
                Surface(
                    color = Color(0xFF0B0F17),
                    border = BorderStroke(1.dp, TitaniumCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(6.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("QUICK DECK:", color = IndustrialAmber, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            SmallHudButton("▶ Jalankan File Ini") {
                                scope.launch {
                                    isRunningCommand = true
                                    val ext = File(activeFilePath).extension.lowercase()
                                    val cmd = when (ext) {
                                        "py" -> "python3 \"$activeFilePath\""
                                        "js" -> "node \"$activeFilePath\""
                                        "sh" -> "sh \"$activeFilePath\""
                                        else -> "ls -la"
                                    }
                                    terminalOutput += "\n$ $cmd\n" + engineManager.runTerminalCommand(cmd, currentDirectory)
                                    isRunningCommand = false
                                }
                            }
                            SmallHudButton("Cek Isi Folder") {
                                scope.launch {
                                    terminalOutput += "\n$ ls -lh\n" + engineManager.runTerminalCommand("ls -lh", currentDirectory)
                                }
                            }
                            SmallHudButton("Perbaiki Izin File") {
                                scope.launch {
                                    terminalOutput += "\n$ chmod -R 755 .\n" + engineManager.runTerminalCommand("chmod -R 755 .", currentDirectory)
                                }
                            }
                            SmallHudButton("Cek Sistem & RAM") {
                                scope.launch {
                                    terminalOutput += "\n$ uname -a && free -m\n" + engineManager.runTerminalCommand("uname -a", currentDirectory)
                                }
                            }
                            SmallHudButton("AI: Perbaiki Error Ini") {
                                isSidebarVisible = true
                                activeSidebarTab = SidebarTab.AI_AGENT
                                aiPromptInput = "AI, tolong baca log error terminal ini dan perbaiki kodenya:\n${terminalOutput.takeLast(1200)}"
                            }
                            SmallHudButton("Bersihkan") {
                                terminalOutput = "[HUD_TERM] Layar terminal dibersihkan.\n"
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = terminalOutput,
                            color = SignalEmerald,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .background(ObsidianBg)
                                .padding(6.dp)
                                .verticalScroll(rememberScrollState())
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            OutlinedTextField(
                                value = terminalInput,
                                onValueChange = { terminalInput = it },
                                placeholder = { Text("Ketik perintah opsional...", fontSize = 10.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            SmallHudButton(if (isRunningCommand) "Running..." else "Kirim") {
                                if (terminalInput.isNotBlank()) {
                                    val cmd = terminalInput
                                    terminalInput = ""
                                    scope.launch {
                                        isRunningCommand = true
                                        terminalOutput += "\n$ $cmd\n" + engineManager.runTerminalCommand(cmd, currentDirectory)
                                        isRunningCommand = false
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Surface(
                color = GunmetalPanel,
                border = BorderStroke(1.dp, HudBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SmallHudButton("SAVE") {
                            if (activeFilePath.isNotBlank()) {
                                scope.launch {
                                    val r = engineManager.writeFileContent(activeFilePath, activeFileContent)
                                    statusBanner = r.getOrDefault("Gagal menyimpan")
                                }
                            }
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        SmallHudButton("UNDO") { webViewRef?.evaluateJavascript("window.editorUndo();", null) }
                        Spacer(modifier = Modifier.width(4.dp))
                        SmallHudButton("REDO") { webViewRef?.evaluateJavascript("window.editorRedo();", null) }
                        Spacer(modifier = Modifier.width(4.dp))
                        SmallHudButton("FIND") { webViewRef?.evaluateJavascript("window.toggleFindOverlay(true);", null) }
                        Spacer(modifier = Modifier.width(6.dp))

                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            val quickSymbols = listOf(
                                "    " to "TAB",
                                "{" to "{",
                                "}" to "}",
                                "(" to "(",
                                ")" to ")",
                                "[" to "[",
                                "]" to "]",
                                "=>" to "=>",
                                ";" to ";",
                                "\"" to "\"",
                                "'" to "'",
                                "/" to "/",
                                "// " to "//"
                            )
                            quickSymbols.forEach { (insertVal, label) ->
                                SmallHudButton(label) {
                                    val q = org.json.JSONObject.quote(insertVal)
                                    webViewRef?.evaluateJavascript("window.insertSnippetAtCursor($q);", null)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))
                        var accumDx by remember { mutableFloatStateOf(0f) }
                        var accumDy by remember { mutableFloatStateOf(0f) }
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .width(78.dp)
                                .height(28.dp)
                                .background(SlateSurface, CutCornerShape(4.dp))
                                .border(1.dp, TitaniumCyan, CutCornerShape(4.dp))
                                .pointerInput(Unit) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        accumDx += dragAmount.x
                                        accumDy += dragAmount.y
                                        val stepX = (accumDx / 14f).toInt()
                                        val stepY = (accumDy / 18f).toInt()
                                        if (stepX != 0 || stepY != 0) {
                                            webViewRef?.evaluateJavascript("window.moveCursorByDelta($stepX, $stepY);", null)
                                            accumDx %= 14f
                                            accumDy %= 18f
                                        }
                                    }
                                }
                        ) {
                            Text(
                                text = "✥ TRACKPAD",
                                color = TitaniumCyan,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF07090C))
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = statusBanner,
                            color = TitaniumCyan,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "AUTO-HIBERNATE: 60s ON-EXIT",
                            color = IndustrialAmber,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }
    }

    @Composable
    fun SmallHudButton(text: String, onClick: () -> Unit) {
        Surface(
            color = SlateSurface,
            shape = CutCornerShape(4.dp),
            border = BorderStroke(1.dp, TitaniumCyan.copy(alpha = 0.7f)),
            modifier = Modifier.clickable { onClick() }
        ) {
            Text(
                text = text,
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
            )
        }
    }

    private fun resolveWorkspacePath(workspaceDir: String, rawPath: String): String {
        return if (rawPath.startsWith("/")) {
            rawPath
        } else if (workspaceDir.endsWith("/")) {
            "$workspaceDir$rawPath"
        } else {
            "$workspaceDir/$rawPath"
        }
    }

    private fun startVoiceToAiRecognition(
        onPartialOrFinal: (String) -> Unit,
        onStateChange: (Boolean) -> Unit
    ) {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { onStateChange(true) }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { onStateChange(false) }
                    override fun onError(error: Int) { onStateChange(false) }
                    override fun onResults(results: Bundle?) {
                        onStateChange(false)
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            onPartialOrFinal(matches.first())
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            onPartialOrFinal(matches.first())
                        }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale("id", "ID").toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            onStateChange(false)
            Toast.makeText(this, "Voice error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
