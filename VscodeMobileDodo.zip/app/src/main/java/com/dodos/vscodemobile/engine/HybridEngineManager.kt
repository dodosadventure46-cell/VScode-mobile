package com.dodos.vscodemobile.engine

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.ChannelSftp
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.charset.StandardCharsets
import java.util.Properties
import java.util.Vector
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

enum class EngineMode {
    LOCAL,
    SSH_REMOTE
}

data class SshCredentials(
    val host: String = "",
    val port: Int = 22,
    val username: String = "root",
    val password: String = "",
    val remoteWorkspace: String = "/root/workspace",
    val autoReconnect: Boolean = true
)

data class FileNode(
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val sizeBytes: Long = 0L,
    val lastModified: Long = 0L,
    val hasOfflineDraft: Boolean = false
)

data class VsCodeExtensionItem(
    val id: String,
    val name: String,
    val publisher: String,
    val version: String,
    val description: String,
    val downloadUrl: String,
    val isInstalled: Boolean = false
)

data class SavedSessionState(
    val engineMode: EngineMode,
    val activeWorkspacePath: String,
    val openFiles: List<String>,
    val activeFilePath: String,
    val cursorLine: Int,
    val cursorColumn: Int,
    val fontSizePx: Int,
    val timestamp: Long
)

class HybridEngineManager(private val context: Context) {

    private val prefs: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "vscodedodo_secure_vault",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Exception) {
            context.getSharedPreferences("vscodedodo_secure_vault_fallback", Context.MODE_PRIVATE)
        }
    }

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    val localRootDir: File = File(context.filesDir, "workspace").apply { mkdirs() }
    private val crashShieldDir: File = File(context.filesDir, "crash_shield_drafts").apply { mkdirs() }
    private val extensionsDir: File = File(context.filesDir, "vscode_extensions").apply { mkdirs() }

    private var sshSession: Session? = null
    var currentMode: EngineMode = EngineMode.LOCAL
        private set

    init {
        ensureDefaultStarterWorkspace()
        currentMode = if (prefs.getString("last_engine_mode", "LOCAL") == "SSH_REMOTE") {
            EngineMode.SSH_REMOTE
        } else {
            EngineMode.LOCAL
        }
    }

    private fun ensureDefaultStarterWorkspace() {
        val welcomeFile = File(localRootDir, "main.js")
        if (!welcomeFile.exists() && (localRootDir.listFiles()?.isEmpty() != false)) {
            welcomeFile.writeText(
                """
                // =========================================================
                // VscodeMobileDodo • Tactical Hybrid VS Code Environment
                // Mode: Local Offline Engine & Remote SSH Engine
                // =========================================================

                function initializeDodoSystem(config) {
                    const telemetry = {
                        engine: config.mode,
                        status: "ONLINE_READY",
                        aiAgent: "MULTI_PROVIDER_ACTIVE",
                        timestamp: new Date().toISOString()
                    };
                    console.log("[HUD_CORE] System Ready:", JSON.stringify(telemetry, null, 2));
                    return telemetry;
                }

                initializeDodoSystem({ mode: "HYBRID_TACTICAL" });
                """.trimIndent()
            )
            File(localRootDir, "README.md").writeText(
                """
                # VscodeMobileDodo Workspace
                
                Selamat datang di **VscodeMobileDodo**!
                - Gunakan **Activity Bar** di kiri untuk membuka Explorer, Search, Git Source Control, Extensions (OpenVSX / .vsix), SFTP Transfer, atau AI Co-Pilot.
                - Gunakan **Cubit 2 Jari (Pinch-to-Zoom)** pada kode untuk mengubah ukuran huruf secara instan.
                - Geser **Mini Trackpad** di bilah bawah untuk menggerakkan kursor secara presisi per karakter.
                """.trimIndent()
            )
        }
    }

    fun saveSshCredentials(creds: SshCredentials) {
        prefs.edit()
            .putString("ssh_host", creds.host.trim())
            .putInt("ssh_port", creds.port)
            .putString("ssh_user", creds.username.trim())
            .putString("ssh_pass", creds.password)
            .putString("ssh_remote_workspace", creds.remoteWorkspace.ifBlank { "/root/workspace" })
            .putBoolean("ssh_auto_reconnect", creds.autoReconnect)
            .apply()
    }

    fun loadSshCredentials(): SshCredentials {
        return SshCredentials(
            host = prefs.getString("ssh_host", "") ?: "",
            port = prefs.getInt("ssh_port", 22),
            username = prefs.getString("ssh_user", "root") ?: "root",
            password = prefs.getString("ssh_pass", "") ?: "",
            remoteWorkspace = prefs.getString("ssh_remote_workspace", "/root/workspace") ?: "/root/workspace",
            autoReconnect = prefs.getBoolean("ssh_auto_reconnect", true)
        )
    }

    fun hasSavedSshCredentials(): Boolean {
        val c = loadSshCredentials()
        return c.host.isNotBlank() && c.username.isNotBlank() && c.password.isNotBlank()
    }

    fun setEngineMode(mode: EngineMode) {
        currentMode = mode
        prefs.edit().putString("last_engine_mode", mode.name).apply()
    }

    suspend fun connectSsh(creds: SshCredentials = loadSshCredentials()): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (creds.host.isBlank()) {
                return@withContext Result.failure(IllegalArgumentException("Host/IP SSH belum diisi."))
            }
            saveSshCredentials(creds)
            disconnectSsh()

            val jsch = JSch()
            val session = jsch.getSession(creds.username, creds.host, creds.port)
            session.setPassword(creds.password)
            val config = Properties()
            config["StrictHostKeyChecking"] = "no"
            config["PreferredAuthentications"] = "password,keyboard-interactive,publickey"
            session.setConfig(config)
            session.connect(12_000)

            sshSession = session
            setEngineMode(EngineMode.SSH_REMOTE)

            executeRemoteCommand("mkdir -p \"${creds.remoteWorkspace}\"")

            val syncedCount = syncPendingCrashShieldDraftsToRemote()
            val syncMsg = if (syncedCount > 0) " ($syncedCount file draft offline berhasil disinkronkan ulang!)" else ""

            Result.success("Terhubung ke ${creds.username}@${creds.host}:${creds.port}$syncMsg")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun isSshConnected(): Boolean {
        return sshSession?.isConnected == true
    }

    fun disconnectSsh() {
        try {
            sshSession?.disconnect()
        } catch (_: Exception) {}
        sshSession = null
    }

    private fun getDraftFileForPath(filePath: String): File {
        val safeKey = filePath.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        return File(crashShieldDir, "$safeKey.draft")
    }

    private fun getDraftMetaFileForPath(filePath: String): File {
        val safeKey = filePath.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        return File(crashShieldDir, "$safeKey.meta")
    }

    fun saveInstantDraftShield(filePath: String, content: String, isRemote: Boolean) {
        try {
            getDraftFileForPath(filePath).writeText(content, StandardCharsets.UTF_8)
            val meta = JSONObject().apply {
                put("path", filePath)
                put("isRemote", isRemote)
                put("timestamp", System.currentTimeMillis())
            }
            getDraftMetaFileForPath(filePath).writeText(meta.toString(), StandardCharsets.UTF_8)
        } catch (_: Exception) {}
    }

    fun clearDraftShield(filePath: String) {
        try {
            getDraftFileForPath(filePath).delete()
            getDraftMetaFileForPath(filePath).delete()
        } catch (_: Exception) {}
    }

    fun getPendingRemoteDraftCount(): Int {
        return crashShieldDir.listFiles { _, name -> name.endsWith(".meta") }?.count { metaFile ->
            try {
                val obj = JSONObject(metaFile.readText())
                obj.optBoolean("isRemote", false)
            } catch (_: Exception) {
                false
            }
        } ?: 0
    }

    private suspend fun syncPendingCrashShieldDraftsToRemote(): Int = withContext(Dispatchers.IO) {
        var count = 0
        val metaFiles = crashShieldDir.listFiles { _, name -> name.endsWith(".meta") } ?: return@withContext 0
        for (metaFile in metaFiles) {
            try {
                val meta = JSONObject(metaFile.readText())
                if (meta.optBoolean("isRemote", false)) {
                    val remotePath = meta.getString("path")
                    val draftFile = File(crashShieldDir, metaFile.name.removeSuffix(".meta") + ".draft")
                    if (draftFile.exists()) {
                        val content = draftFile.readText(StandardCharsets.UTF_8)
                        val writeRes = writeRemoteFileDirect(remotePath, content)
                        if (writeRes.isSuccess) {
                            draftFile.delete()
                            metaFile.delete()
                            count++
                        }
                    }
                }
            } catch (_: Exception) {}
        }
        count
    }

    suspend fun listFiles(directoryPath: String = getActiveWorkspaceRoot()): Result<List<FileNode>> = withContext(Dispatchers.IO) {
        if (currentMode == EngineMode.LOCAL) {
            try {
                val dir = File(directoryPath)
                if (!dir.exists()) dir.mkdirs()
                val nodes = (dir.listFiles() ?: emptyArray())
                    .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
                    .map { f ->
                        FileNode(
                            name = f.name,
                            path = f.absolutePath,
                            isDirectory = f.isDirectory,
                            sizeBytes = if (f.isDirectory) 0L else f.length(),
                            lastModified = f.lastModified(),
                            hasOfflineDraft = getDraftFileForPath(f.absolutePath).exists()
                        )
                    }
                Result.success(nodes)
            } catch (e: Exception) {
                Result.failure(e)
            }
        } else {
            listRemoteFilesSftp(directoryPath)
        }
    }

    fun getActiveWorkspaceRoot(): String {
        return if (currentMode == EngineMode.LOCAL) {
            localRootDir.absolutePath
        } else {
            loadSshCredentials().remoteWorkspace
        }
    }

    private suspend fun listRemoteFilesSftp(remoteDir: String): Result<List<FileNode>> = withContext(Dispatchers.IO) {
        try {
            val session = ensureSshSession()
            val channel = session.openChannel("sftp") as ChannelSftp
            channel.connect(10_000)
            try {
                @Suppress("UNCHECKED_CAST")
                val entries = channel.ls(remoteDir) as Vector<ChannelSftp.LsEntry>
                val list = mutableListOf<FileNode>()
                for (entry in entries) {
                    val name = entry.filename
                    if (name == "." || name == "..") continue
                    val fullPath = if (remoteDir.endsWith("/")) "$remoteDir$name" else "$remoteDir/$name"
                    list.add(
                        FileNode(
                            name = name,
                            path = fullPath,
                            isDirectory = entry.attrs.isDir,
                            sizeBytes = entry.attrs.size,
                            lastModified = entry.attrs.mTime * 1000L,
                            hasOfflineDraft = getDraftFileForPath(fullPath).exists()
                        )
                    )
                }
                val sorted = list.sortedWith(compareBy<FileNode>({ !it.isDirectory }, { it.name.lowercase() }))
                Result.success(sorted)
            } finally {
                channel.disconnect()
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun readFileContent(filePath: String): Result<String> = withContext(Dispatchers.IO) {
        val draftFile = getDraftFileForPath(filePath)
        if (currentMode == EngineMode.LOCAL) {
            try {
                val f = File(filePath)
                if (!f.exists()) return@withContext Result.failure(IllegalArgumentException("File tidak ditemukan: $filePath"))
                Result.success(f.readText(StandardCharsets.UTF_8))
            } catch (e: Exception) {
                Result.failure(e)
            }
        } else {
            try {
                val session = ensureSshSession()
                val channel = session.openChannel("sftp") as ChannelSftp
                channel.connect(10_000)
                try {
                    val out = ByteArrayOutputStream()
                    channel.get(filePath, out)
                    val remoteText = out.toString("UTF-8")
                    if (draftFile.exists()) {
                        Result.success(draftFile.readText(StandardCharsets.UTF_8))
                    } else {
                        Result.success(remoteText)
                    }
                } finally {
                    channel.disconnect()
                }
            } catch (e: Exception) {
                if (draftFile.exists()) {
                    Result.success(draftFile.readText(StandardCharsets.UTF_8))
                } else {
                    Result.failure(e)
                }
            }
        }
    }

    suspend fun writeFileContent(filePath: String, content: String): Result<String> = withContext(Dispatchers.IO) {
        if (currentMode == EngineMode.LOCAL) {
            try {
                val f = File(filePath)
                f.parentFile?.mkdirs()
                f.writeText(content, StandardCharsets.UTF_8)
                clearDraftShield(filePath)
                Result.success("Tersimpan di Lokal (${f.name})")
            } catch (e: Exception) {
                Result.failure(e)
            }
        } else {
            saveInstantDraftShield(filePath, content, isRemote = true)
            val remoteWrite = writeRemoteFileDirect(filePath, content)
            if (remoteWrite.isSuccess) {
                clearDraftShield(filePath)
                Result.success("Tersimpan di Server SSH (${File(filePath).name})")
            } else {
                Result.success("Sinyal SSH terputus! Kode diamankan di Crash Shield & akan disinkronkan saat sinyal kembali.")
            }
        }
    }

    private fun writeRemoteFileDirect(remotePath: String, content: String): Result<Unit> {
        return try {
            val session = ensureSshSession()
            val channel = session.openChannel("sftp") as ChannelSftp
            channel.connect(10_000)
            try {
                val bytes = content.toByteArray(StandardCharsets.UTF_8)
                channel.put(ByteArrayInputStream(bytes), remotePath, ChannelSftp.OVERWRITE)
                Result.success(Unit)
            } finally {
                channel.disconnect()
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createNewFileOrFolder(parentDir: String, name: String, isFolder: Boolean): Result<String> = withContext(Dispatchers.IO) {
        val targetPath = if (parentDir.endsWith("/")) "$parentDir$name" else "$parentDir/$name"
        if (currentMode == EngineMode.LOCAL) {
            try {
                val f = File(targetPath)
                if (isFolder) {
                    f.mkdirs()
                } else {
                    f.parentFile?.mkdirs()
                    if (!f.exists()) f.writeText("", StandardCharsets.UTF_8)
                }
                Result.success(targetPath)
            } catch (e: Exception) {
                Result.failure(e)
            }
        } else {
            try {
                if (isFolder) {
                    executeRemoteCommand("mkdir -p \"$targetPath\"")
                } else {
                    writeRemoteFileDirect(targetPath, "").getOrThrow()
                }
                Result.success(targetPath)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun deleteFileOrFolder(targetPath: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (currentMode == EngineMode.LOCAL) {
            try {
                File(targetPath).deleteRecursively()
                clearDraftShield(targetPath)
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        } else {
            try {
                executeRemoteCommand("rm -rf \"$targetPath\"")
                clearDraftShield(targetPath)
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun downloadRemoteFileToLocal(remotePath: String, localDestDir: File = localRootDir): Result<File> = withContext(Dispatchers.IO) {
        try {
            val session = ensureSshSession()
            val channel = session.openChannel("sftp") as ChannelSftp
            channel.connect(10_000)
            try {
                localDestDir.mkdirs()
                val destFile = File(localDestDir, File(remotePath).name)
                channel.get(remotePath, destFile.absolutePath)
                Result.success(destFile)
            } finally {
                channel.disconnect()
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun uploadLocalFileToRemote(localFile: File, remoteDestDir: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val session = ensureSshSession()
            val channel = session.openChannel("sftp") as ChannelSftp
            channel.connect(10_000)
            try {
                val targetPath = if (remoteDestDir.endsWith("/")) "${remoteDestDir}${localFile.name}" else "$remoteDestDir/${localFile.name}"
                channel.put(localFile.absolutePath, targetPath, ChannelSftp.OVERWRITE)
                Result.success(targetPath)
            } finally {
                channel.disconnect()
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun runTerminalCommand(command: String, workingDir: String = getActiveWorkspaceRoot()): String = withContext(Dispatchers.IO) {
        if (currentMode == EngineMode.LOCAL) {
            try {
                val dir = File(workingDir).apply { if (!exists()) mkdirs() }
                val pb = ProcessBuilder("sh", "-c", command)
                pb.directory(dir)
                pb.redirectErrorStream(true)
                val env = pb.environment()
                env["HOME"] = context.filesDir.absolutePath
                env["TMPDIR"] = context.cacheDir.absolutePath
                val proc = pb.start()
                val finished = proc.waitFor(30, TimeUnit.SECONDS)
                val output = proc.inputStream.bufferedReader().readText()
                if (!finished) {
                    proc.destroyForcibly()
                    "$output\n[HUD_WARN] Perintah dihentikan karena melewati batas waktu 30 detik."
                } else {
                    output.ifBlank { "[OK] Perintah selesai dieksekusi (Exit code: ${proc.exitValue()})." }
                }
            } catch (e: Exception) {
                "[LOCAL_TERM_ERR] ${e.message}"
            }
        } else {
            executeRemoteCommand("cd \"$workingDir\" && $command")
        }
    }

    suspend fun executeRemoteCommand(command: String): String = withContext(Dispatchers.IO) {
        try {
            val session = ensureSshSession()
            val channel = session.openChannel("exec") as ChannelExec
            channel.setCommand("$command 2>&1")
            val out = ByteArrayOutputStream()
            channel.outputStream = out
            channel.connect(10_000)
            val start = System.currentTimeMillis()
            while (!channel.isClosed && System.currentTimeMillis() - start < 30_000L) {
                Thread.sleep(80)
            }
            val result = out.toString("UTF-8")
            channel.disconnect()
            result.ifBlank { "[SSH_OK] Perintah selesai (Exit: ${channel.exitStatus})." }
        } catch (e: Exception) {
            "[SSH_TERM_ERR] ${e.message}"
        }
    }

    private fun ensureSshSession(): Session {
        val current = sshSession
        if (current != null && current.isConnected) return current
        val creds = loadSshCredentials()
        if (creds.host.isBlank()) throw IllegalStateException("Kredensial SSH belum diatur.")
        val jsch = JSch()
        val session = jsch.getSession(creds.username, creds.host, creds.port)
        session.setPassword(creds.password)
        val config = Properties()
        config["StrictHostKeyChecking"] = "no"
        session.setConfig(config)
        session.connect(10_000)
        sshSession = session
        return session
    }

    suspend fun searchOpenVsxExtensions(query: String): Result<List<VsCodeExtensionItem>> = withContext(Dispatchers.IO) {
        try {
            val encoded = java.net.URLEncoder.encode(query.ifBlank { "theme" }, "UTF-8")
            val url = "https://open-vsx.org/api/-/search?query=$encoded&size=18"
            val req = Request.Builder().url(url).get().build()
            val resp = httpClient.newCall(req).execute()
            val body = resp.body?.string() ?: "{}"
            val json = JSONObject(body)
            val arr = json.optJSONArray("extensions") ?: JSONArray()
            val installedIds = getInstalledExtensions().map { it.id }.toSet()
            val results = mutableListOf<VsCodeExtensionItem>()
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                val namespace = item.optString("namespace", "publisher")
                val name = item.optString("name", "ext")
                val id = "$namespace.$name"
                val filesObj = item.optJSONObject("files")
                val downloadUrl = filesObj?.optString("download", "") ?: ""
                results.add(
                    VsCodeExtensionItem(
                        id = id,
                        name = item.optString("displayName", name).ifBlank { name },
                        publisher = namespace,
                        version = item.optString("version", "1.0.0"),
                        description = item.optString("description", "Ekstensi VS Code dari OpenVSX Registry"),
                        downloadUrl = downloadUrl,
                        isInstalled = installedIds.contains(id)
                    )
                )
            }
            Result.success(results)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun installExtensionFromOpenVsx(ext: VsCodeExtensionItem): Result<String> = withContext(Dispatchers.IO) {
        try {
            val targetDir = File(extensionsDir, ext.id).apply { mkdirs() }
            if (ext.downloadUrl.isNotBlank()) {
                val req = Request.Builder().url(ext.downloadUrl).get().build()
                val resp = httpClient.newCall(req).execute()
                val bytes = resp.body?.bytes()
                if (bytes != null && bytes.isNotEmpty()) {
                    val vsixFile = File(targetDir, "${ext.id}-${ext.version}.vsix")
                    vsixFile.writeBytes(bytes)
                    extractVsixArchive(vsixFile, targetDir)
                }
            }
            val meta = JSONObject().apply {
                put("id", ext.id)
                put("name", ext.name)
                put("publisher", ext.publisher)
                put("version", ext.version)
                put("description", ext.description)
                put("downloadUrl", ext.downloadUrl)
            }
            File(targetDir, "manifest_dodo.json").writeText(meta.toString(2), StandardCharsets.UTF_8)
            Result.success("Plugin ${ext.name} (${ext.version}) berhasil dipasang dan diaktifkan!")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getInstalledExtensions(): List<VsCodeExtensionItem> {
        val list = mutableListOf<VsCodeExtensionItem>()
        val dirs = extensionsDir.listFiles() ?: return list
        for (d in dirs) {
            val metaFile = File(d, "manifest_dodo.json")
            if (metaFile.exists()) {
                try {
                    val obj = JSONObject(metaFile.readText())
                    list.add(
                        VsCodeExtensionItem(
                            id = obj.optString("id"),
                            name = obj.optString("name"),
                            publisher = obj.optString("publisher"),
                            version = obj.optString("version"),
                            description = obj.optString("description"),
                            downloadUrl = obj.optString("downloadUrl"),
                            isInstalled = true
                        )
                    )
                } catch (_: Exception) {}
            }
        }
        return list
    }

    private fun extractVsixArchive(vsixFile: File, destDir: File) {
        try {
            ZipInputStream(vsixFile.inputStream()).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val outFile = File(destDir, entry.name)
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        outFile.outputStream().use { zis.copyTo(it) }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        } catch (_: Exception) {}
    }

    suspend fun exportWorkspaceToZipBytes(): ByteArray = withContext(Dispatchers.IO) {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { zos ->
            val files = localRootDir.walkTopDown().filter { it.isFile }.toList()
            for (file in files) {
                val relPath = file.relativeTo(localRootDir).path
                zos.putNextEntry(ZipEntry(relPath))
                file.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        bos.toByteArray()
    }

    fun saveLastSessionState(state: SavedSessionState) {
        val obj = JSONObject().apply {
            put("engineMode", state.engineMode.name)
            put("activeWorkspacePath", state.activeWorkspacePath)
            put("openFiles", JSONArray(state.openFiles))
            put("activeFilePath", state.activeFilePath)
            put("cursorLine", state.cursorLine)
            put("cursorColumn", state.cursorColumn)
            put("fontSizePx", state.fontSizePx)
            put("timestamp", state.timestamp)
        }
        prefs.edit().putString("saved_last_session_state", obj.toString()).apply()
    }

    fun loadLastSessionState(): SavedSessionState? {
        val raw = prefs.getString("saved_last_session_state", null) ?: return null
        return try {
            val obj = JSONObject(raw)
            val arr = obj.optJSONArray("openFiles") ?: JSONArray()
            val openFiles = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                openFiles.add(arr.getString(i))
            }
            SavedSessionState(
                engineMode = if (obj.optString("engineMode") == "SSH_REMOTE") EngineMode.SSH_REMOTE else EngineMode.LOCAL,
                activeWorkspacePath = obj.optString("activeWorkspacePath", localRootDir.absolutePath),
                openFiles = openFiles,
                activeFilePath = obj.optString("activeFilePath", ""),
                cursorLine = obj.optInt("cursorLine", 1),
                cursorColumn = obj.optInt("cursorColumn", 1),
                fontSizePx = obj.optInt("fontSizePx", 14),
                timestamp = obj.optLong("timestamp", System.currentTimeMillis())
            )
        } catch (_: Exception) {
            null
        }
    }

    fun exportFullConfigurationJson(aiPrefsJson: JSONObject): String {
        val root = JSONObject()
        root.put("app", "VscodeMobileDodo")
        root.put("exportedAt", System.currentTimeMillis())
        val ssh = loadSshCredentials()
        root.put("sshCredentials", JSONObject().apply {
            put("host", ssh.host)
            put("port", ssh.port)
            put("username", ssh.username)
            put("password", ssh.password)
            put("remoteWorkspace", ssh.remoteWorkspace)
            put("autoReconnect", ssh.autoReconnect)
        })
        root.put("aiConfig", aiPrefsJson)
        val extArr = JSONArray()
        for (ext in getInstalledExtensions()) {
            extArr.put(JSONObject().apply {
                put("id", ext.id)
                put("name", ext.name)
                put("publisher", ext.publisher)
                put("version", ext.version)
                put("description", ext.description)
                put("downloadUrl", ext.downloadUrl)
            })
        }
        root.put("installedExtensions", extArr)
        return root.toString(2)
    }

    fun importFullConfigurationJson(rawJson: String): Result<JSONObject> {
        return try {
            val root = JSONObject(rawJson)
            root.optJSONObject("sshCredentials")?.let { s ->
                saveSshCredentials(
                    SshCredentials(
                        host = s.optString("host"),
                        port = s.optInt("port", 22),
                        username = s.optString("username", "root"),
                        password = s.optString("password"),
                        remoteWorkspace = s.optString("remoteWorkspace", "/root/workspace"),
                        autoReconnect = s.optBoolean("autoReconnect", true)
                    )
                )
            }
            val extArr = root.optJSONArray("installedExtensions") ?: JSONArray()
            for (i in 0 until extArr.length()) {
                val ext = extArr.getJSONObject(i)
                val id = ext.optString("id")
                if (id.isNotBlank()) {
                    val dir = File(extensionsDir, id).apply { mkdirs() }
                    File(dir, "manifest_dodo.json").writeText(ext.toString(2), StandardCharsets.UTF_8)
                }
            }
            Result.success(root.optJSONObject("aiConfig") ?: JSONObject())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
