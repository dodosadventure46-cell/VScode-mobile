package com.dodos.vscodemobile.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.os.Process
import androidx.core.app.NotificationCompat
import com.dodos.vscodemobile.MainActivity
import kotlin.system.exitProcess

class SessionGuardianService : Service() {

    companion object {
        const val CHANNEL_ID = "vscode_dodo_session_channel"
        const val NOTIF_ID = 4041
        const val ACTION_START_GUARD = "ACTION_START_GUARD"
        const val ACTION_APP_BACKGROUNDED = "ACTION_APP_BACKGROUNDED"
        const val ACTION_APP_FOREGROUNDED = "ACTION_APP_FOREGROUNDED"
        const val ACTION_FORCE_SHUTDOWN_NOW = "ACTION_FORCE_SHUTDOWN_NOW"

        var onSaveSessionCallback: (() -> Unit)? = null
        var onForceFinishActivityCallback: (() -> Unit)? = null
    }

    private var exitCountDownTimer: CountDownTimer? = null
    private var isBackgroundCountdownActive = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_GUARD -> {
                startForeground(NOTIF_ID, buildNotification("Mesin VscodeMobileDodo Aktif • Sesi Terlindungi"))
            }
            ACTION_APP_BACKGROUNDED -> {
                startSixtySecondHibernateTimer()
            }
            ACTION_APP_FOREGROUNDED -> {
                cancelSixtySecondHibernateTimer()
                updateNotification("Mesin VscodeMobileDodo Aktif • Sesi Terlindungi")
            }
            ACTION_FORCE_SHUTDOWN_NOW -> {
                triggerAutoSaveAndForceClose()
            }
        }
        return START_NOT_STICKY
    }

    private fun startSixtySecondHibernateTimer() {
        exitCountDownTimer?.cancel()
        isBackgroundCountdownActive = true
        // Simpan snapshot awal begitu keluar aplikasi agar tidak ada ketikan hilang
        try {
            onSaveSessionCallback?.invoke()
        } catch (_: Exception) {}

        exitCountDownTimer = object : CountDownTimer(60_000L, 5_000L) {
            override fun onTick(millisUntilFinished: Long) {
                val secLeft = (millisUntilFinished / 1000L).coerceAtLeast(1L)
                updateNotification("Di luar aplikasi: Otomatis simpan & matikan paksa dalam ${secLeft}d")
            }

            override fun onFinish() {
                if (isBackgroundCountdownActive) {
                    triggerAutoSaveAndForceClose()
                }
            }
        }.start()
    }

    private fun cancelSixtySecondHibernateTimer() {
        isBackgroundCountdownActive = false
        exitCountDownTimer?.cancel()
        exitCountDownTimer = null
    }

    private fun triggerAutoSaveAndForceClose() {
        isBackgroundCountdownActive = false
        exitCountDownTimer?.cancel()
        try {
            onSaveSessionCallback?.invoke()
        } catch (_: Exception) {}
        try {
            onForceFinishActivityCallback?.invoke()
        } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        Process.killProcess(Process.myPid())
        exitProcess(0)
    }

    private fun updateNotification(statusText: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(statusText))
    }

    private fun buildNotification(statusText: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, SessionGuardianService::class.java).apply {
            action = ACTION_FORCE_SHUTDOWN_NOW
        }
        val pendingStop = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VscodeMobileDodo • Tactical HUD")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .setContentIntent(pendingOpen)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Simpan & Matikan", pendingStop)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "VscodeMobileDodo Session Guardian",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Menjaga sesi VS Code dan mematikan otomatis setelah 60 detik di luar aplikasi"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
