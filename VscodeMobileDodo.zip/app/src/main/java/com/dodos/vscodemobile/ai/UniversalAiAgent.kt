package com.dodos.vscodemobile.ai

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class AiProvider(
    val displayName: String,
    val defaultBaseUrl: String,
    val defaultModels: List<String>
) {
    GEMINI(
        "Google Gemini",
        "https://generativelanguage.googleapis.com/v1beta",
        listOf("gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.5-flash-lite")
    ),
    GROQ(
        "Groq Cloud (Super Cepat)",
        "https://api.groq.com/openai/v1/chat/completions",
        listOf("llama-3.3-70b-versatile", "deepseek-r1-distill-llama-70b", "qwen-qwq-32b")
    ),
    OPENAI(
        "ChatGPT / OpenAI",
        "https://api.openai.com/v1/chat/completions",
        listOf("gpt-4o", "gpt-4o-mini", "o3-mini")
    ),
    DEEPSEEK(
        "DeepSeek AI",
        "https://api.deepseek.com/v1/chat/completions",
        listOf("deepseek-chat", "deepseek-reasoner")
    ),
    OPENROUTER(
        "OpenRouter (Semua AI)",
        "https://openrouter.ai/api/v1/chat/completions",
        listOf("anthropic/claude-3.5-sonnet", "google/gemini-2.5-pro", "deepseek/deepseek-chat")
    ),
    CUSTOM(
        "Custom Endpoint (Bebas)",
        "https://api.openai.com/v1/chat/completions",
        listOf("custom-model")
    )
}

data class AiProposedFileChange(
    val filePath: String,
    val action: String, // "modify" or "create"
    val previousContent: String?,
    val newContent: String,
    val unifiedDiffPreview: String
)

data class AiUndoSnapshot(
    val timestamp: Long,
    val summary: String,
    val previousFilesState: Map<String, String?> // null means file didn't exist before AI created it
)

data class AiAgentResponse(
    val explanationText: String,
    val proposedChanges: List<AiProposedFileChange>
)

class UniversalAiAgent(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("vscodedodo_ai_prefs", Context.MODE_PRIVATE)

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    private val undoStack = ArrayDeque<AiUndoSnapshot>()

    fun getSelectedProvider(): AiProvider {
        val name = prefs.getString("selected_provider", AiProvider.GEMINI.name) ?: AiProvider.GEMINI.name
        return try {
            AiProvider.valueOf(name)
        } catch (_: Exception) {
            AiProvider.GEMINI
        }
    }

    fun setSelectedProvider(provider: AiProvider) {
        prefs.edit().putString("selected_provider", provider.name).apply()
    }

    fun getApiKey(provider: AiProvider = getSelectedProvider()): String {
        return prefs.getString("api_key_${provider.name}", "") ?: ""
    }

    fun setApiKey(provider: AiProvider, apiKey: String) {
        prefs.edit().putString("api_key_${provider.name}", apiKey.trim()).apply()
    }

    fun getSelectedModel(provider: AiProvider = getSelectedProvider()): String {
        return prefs.getString("model_${provider.name}", provider.defaultModels.first())
            ?: provider.defaultModels.first()
    }

    fun setSelectedModel(provider: AiProvider, model: String) {
        prefs.edit().putString("model_${provider.name}", model.trim()).apply()
    }

    fun getCustomBaseUrl(): String {
        return prefs.getString("custom_base_url", AiProvider.CUSTOM.defaultBaseUrl)
            ?: AiProvider.CUSTOM.defaultBaseUrl
    }

    fun setCustomBaseUrl(url: String) {
        prefs.edit().putString("custom_base_url", url.trim()).apply()
    }

    fun isAutoApplyEnabled(): Boolean {
        return prefs.getBoolean("ai_auto_apply", true)
    }

    fun setAutoApplyEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("ai_auto_apply", enabled).apply()
    }

    fun exportAiPrefsToJson(): JSONObject {
        val obj = JSONObject()
        obj.put("selected_provider", getSelectedProvider().name)
        obj.put("custom_base_url", getCustomBaseUrl())
        obj.put("ai_auto_apply", isAutoApplyEnabled())
        for (p in AiProvider.entries) {
            obj.put("api_key_${p.name}", getApiKey(p))
            obj.put("model_${p.name}", getSelectedModel(p))
        }
        return obj
    }

    fun importAiPrefsFromJson(obj: JSONObject) {
        val ed = prefs.edit()
        if (obj.has("selected_provider")) ed.putString("selected_provider", obj.optString("selected_provider"))
        if (obj.has("custom_base_url")) ed.putString("custom_base_url", obj.optString("custom_base_url"))
        if (obj.has("ai_auto_apply")) ed.putBoolean("ai_auto_apply", obj.optBoolean("ai_auto_apply", true))
        for (p in AiProvider.entries) {
            if (obj.has("api_key_${p.name}")) ed.putString("api_key_${p.name}", obj.optString("api_key_${p.name}"))
            if (obj.has("model_${p.name}")) ed.putString("model_${p.name}", obj.optString("model_${p.name}"))
        }
        ed.apply()
    }

    fun pushUndoSnapshot(snapshot: AiUndoSnapshot) {
        undoStack.addLast(snapshot)
        if (undoStack.size > 20) {
            undoStack.removeFirst()
        }
    }

    fun popUndoSnapshot(): AiUndoSnapshot? {
        return if (undoStack.isEmpty()) null else undoStack.removeLast()
    }

    fun getUndoCount(): Int = undoStack.size

    suspend fun askAiCodeAgent(
        userPrompt: String,
        activeFilePath: String,
        activeFileContent: String,
        projectFileList: List<String>,
        recentTerminalLog: String,
        readExistingFileCallback: suspend (String) -> String?
    ): Result<AiAgentResponse> = withContext(Dispatchers.IO) {
        val provider = getSelectedProvider()
        val apiKey = getApiKey(provider)
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("API Key untuk ${provider.displayName} belum diisi. Ketuk ikon Pengaturan AI untuk memasukkan API Key milikmu.")
            )
        }
        val model = getSelectedModel(provider)

        val systemInstruction = """
            Kamu adalah AI Code Agent terintegrasi di dalam aplikasi VscodeMobileDodo (VS Code Mobile Android).
            Gaya komunikasimu harus langsung ke inti, ramah, jelas, berbahasa Indonesia, dan anti-basa-basi.
            Kamu memiliki akses penuh ke:
            1. Daftar seluruh file di workspace proyek pengguna.
            2. Isi lengkap file yang sedang dibuka pengguna saat ini.
            3. Log output / error terbaru dari Smart Terminal.

            ATURAN MENGUBAH ATAU MEMBUAT FILE:
            Jika pengguna meminta mengecek kualitas kode ("file ku sudah cukup bagus belum?"), berikan ulasan tajam, tunjukkan potensi bug/peningkatan, dan jika perlu perbaikan, sertakan blok perubahan file.
            Jika pengguna meminta membuat atau memodifikasi satu atau beberapa file ("buatkan aku...", "perbaiki error ini", "ubah file ini"), WAJIB sertakan isi file lengkap yang baru dengan format tag persis berikut:

            <<<FILE_EDIT path="nama_file_atau_path_relatif" action="modify">>>
            ...isi kode lengkap yang sudah diperbarui tanpa dipotong...
            <<<END_FILE_EDIT>>>

            Jika membuat file baru, gunakan action="create" dan tulis path relatifnya di dalam workspace.
        """.trimIndent()

        val contextPrompt = buildString {
            appendLine("=== KONTEKS PROYEK VSCODEMOBILEDODO ===")
            appendLine("Daftar File di Workspace (${projectFileList.size} file):")
            projectFileList.take(60).forEach { appendLine("- $it") }
            appendLine()
            appendLine("=== FILE AKTIF SAAT INI: $activeFilePath ===")
            appendLine("```")
            appendLine(activeFileContent.take(18_000))
            appendLine("```")
            if (recentTerminalLog.isNotBlank()) {
                appendLine()
                appendLine("=== LOG / ERROR SMART TERMINAL TERBARU ===")
                appendLine("```")
                appendLine(recentTerminalLog.takeLast(4_000))
                appendLine("```")
            }
            appendLine()
            appendLine("=== PERMINTAAN PENGGUNA ===")
            appendLine(userPrompt)
        }

        try {
            val rawReply = when (provider) {
                AiProvider.GEMINI -> callGeminiApi(apiKey, model, systemInstruction, contextPrompt)
                else -> {
                    val endpoint = if (provider == AiProvider.CUSTOM) getCustomBaseUrl() else provider.defaultBaseUrl
                    callOpenAiCompatibleApi(endpoint, apiKey, model, systemInstruction, contextPrompt)
                }
            }
            val parsed = parseAiResponseWithDiffs(rawReply, activeFilePath, activeFileContent, readExistingFileCallback)
            Result.success(parsed)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun callGeminiApi(apiKey: String, model: String, systemPrompt: String, userPrompt: String): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
        val payload = JSONObject().apply {
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            })
            put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.25)
            })
        }
        val req = Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(req).execute().use { resp ->
            val bodyStr = resp.body?.string() ?: ""
            if (!resp.isSuccessful) {
                throw IllegalStateException("Gemini API Error (${resp.code}): ${bodyStr.take(300)}")
            }
            val json = JSONObject(bodyStr)
            val candidates = json.optJSONArray("candidates") ?: JSONArray()
            if (candidates.length() == 0) return "Tidak ada respons dari model Gemini."
            val parts = candidates.getJSONObject(0)
                .optJSONObject("content")
                ?.optJSONArray("parts") ?: JSONArray()
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                sb.append(parts.getJSONObject(i).optString("text", ""))
            }
            return sb.toString()
        }
    }

    private fun callOpenAiCompatibleApi(
        endpoint: String,
        apiKey: String,
        model: String,
        systemPrompt: String,
        userPrompt: String
    ): String {
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", systemPrompt))
            .put(JSONObject().put("role", "user").put("content", userPrompt))

        val payload = JSONObject().apply {
            put("model", model)
            put("messages", messages)
            put("temperature", 0.25)
        }
        val req = Request.Builder()
            .url(endpoint)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(req).execute().use { resp ->
            val bodyStr = resp.body?.string() ?: ""
            if (!resp.isSuccessful) {
                throw IllegalStateException("AI API Error (${resp.code}): ${bodyStr.take(300)}")
            }
            val json = JSONObject(bodyStr)
            val choices = json.optJSONArray("choices") ?: JSONArray()
            if (choices.length() == 0) return "Tidak ada respons dari server AI."
            return choices.getJSONObject(0)
                .optJSONObject("message")
                ?.optString("content", "") ?: ""
        }
    }

    private suspend fun parseAiResponseWithDiffs(
        rawReply: String,
        activeFilePath: String,
        activeFileContent: String,
        readExistingFileCallback: suspend (String) -> String?
    ): AiAgentResponse {
        val regex = Regex(
            """<<<FILE_EDIT\s+path="([^"]+)"(?:\s+action="([^"]+)")?\s*>>>\s*
?(.*?)
?<<<END_FILE_EDIT>>>""",
            setOf(RegexOption.DOT_MATCHES_ALL)
        )
        val changes = mutableListOf<AiProposedFileChange>()
        for (match in regex.findAll(rawReply)) {
            val rawPath = match.groupValues[1].trim()
            val action = match.groupValues[2].ifBlank { "modify" }
            val newCode = match.groupValues[3].trim('', '
')
            val prevContent = if (rawPath == activeFilePath || activeFilePath.endsWith("/$rawPath")) {
                activeFileContent
            } else {
                readExistingFileCallback(rawPath)
            }
            val diffText = buildCompactUnifiedDiff(prevContent ?: "", newCode)
            changes.add(
                AiProposedFileChange(
                    filePath = rawPath,
                    action = action,
                    previousContent = prevContent,
                    newContent = newCode,
                    unifiedDiffPreview = diffText
                )
            )
        }
        val cleanExplanation = rawReply.replace(regex, "").trim()
        return AiAgentResponse(
            explanationText = cleanExplanation.ifBlank { "Perubahan file telah disiapkan oleh AI." },
            proposedChanges = changes
        )
    }

    private fun buildCompactUnifiedDiff(oldText: String, newText: String): String {
        val oldLines = if (oldText.isEmpty()) emptyList() else oldText.lines()
        val newLines = if (newText.isEmpty()) emptyList() else newText.lines()
        val sb = StringBuilder()
        val maxLines = maxOf(oldLines.size, newLines.size).coerceAtMost(80)
        var diffCount = 0
        for (i in 0 until maxLines) {
            val o = oldLines.getOrNull(i)
            val n = newLines.getOrNull(i)
            if (o != n) {
                if (o != null) sb.appendLine("- [${i + 1}] $o")
                if (n != null) sb.appendLine("+ [${i + 1}] $n")
                diffCount++
            }
        }
        if (diffCount == 0 && oldText != newText) {
            sb.appendLine("+ File diperbarui (${newLines.size} baris)")
        } else if (oldLines.size > 80 || newLines.size > 80) {
            sb.appendLine("... (Menampilkan ringkasan diff hingga 80 baris pertama)")
        }
        return sb.toString().ifBlank { "Tidak ada perbedaan baris." }
    }
}
