plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val runNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
val computedVersionCode = 1000 + runNumber

android {
    namespace = "com.dodos.vscodemobile"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.dodos.vscodemobile"
        minSdk = 26
        targetSdk = 34
        versionCode = computedVersionCode
        versionName = "2.0.$runNumber-ROBOTIC"

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    signingConfigs {
        create("dodosPersistentSign") {
            storeFile = file("vscodedodo-release.jks")
            storePassword = "dodosvscode2026"
            keyAlias = "vscodedodo"
            keyPassword = "dodosvscode2026"
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
        }
    }

    buildTypes {
        getByName("debug") {
            // Gunakan keystore yang sama persis agar debug & release tidak pernah bentrok signature!
            signingConfig = signingConfigs.getByName("dodosPersistentSign")
            isDebuggable = true
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("dodosPersistentSign")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-process:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.jcraft:jsch:0.1.55")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.nanohttpd:nanohttpd:2.3.1")
}
